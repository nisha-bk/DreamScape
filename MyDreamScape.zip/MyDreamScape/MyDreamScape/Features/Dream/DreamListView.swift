import SwiftUI
import RealmSwift

struct DreamListView: View {
    @StateObject private var viewModel = DreamViewModel()

    var body: some View {
        NavigationView {
            ZStack {
                // Dreamy background
                LinearGradient(
                    gradient: Gradient(colors: [Color.indigo.opacity(0.4), Color.purple.opacity(0.3), Color.cyan.opacity(0.3)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                List {
                    ForEach(viewModel.dreams) { dream in
                        NavigationLink(destination: DreamDetailView(dream: dream)) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(dream.text)
                                    .font(.body)
                                    .foregroundColor(.primary)
                                    .lineLimit(2)

                                Text(dream.date, style: .date)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .background(.ultraThinMaterial)
                            .cornerRadius(16)
                            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                        }
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    }
                    .onDelete(perform: viewModel.deleteDream)
                }
                .listStyle(.plain)
            }
            .navigationTitle("🌙 Dream Journal")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: AddDreamView()) {
                        Image(systemName: "plus")
                            .font(.title2)
                            .foregroundColor(.indigo)
                    }
                }
            }
        }
    }
}
