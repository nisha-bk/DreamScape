//
//  DreamDetailView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI

struct DreamDetailView: View {
    let dream: DreamEntry

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.mint.opacity(0.2), Color.cyan.opacity(0.3), Color.white]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("📝 Dream Details")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.indigo)

                Text(dream.text)
                    .font(.body)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)

                Text("Date: \(dream.date.formatted(date: .abbreviated, time: .shortened))")
                    .font(.footnote)
                    .foregroundColor(.gray)

                Spacer()
            }
            .padding()
        }
        .navigationTitle("Dream")
    }
}
