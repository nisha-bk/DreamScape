import SwiftUI
import RealmSwift

struct AddDreamView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedResults(DreamEntry.self) var dreams
    @State private var dreamText = ""
    @State private var showSaved = false

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.pink.opacity(0.3), Color.blue.opacity(0.3), Color.white]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Write About Your Dream")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.indigo)

                TextEditor(text: $dreamText)
                    .padding()
                    .frame(height: 200)
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.indigo.opacity(0.2), lineWidth: 1)
                    )
                    .shadow(color: .purple.opacity(0.1), radius: 4, x: 0, y: 2)

                Button(action: {
                    guard !dreamText.isEmpty else { return }
                    let newDream = DreamEntry()
                    newDream.text = dreamText
                    newDream.date = Date()

                    $dreams.append(newDream)
                    dreamText = ""
                    showSaved = true

                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        dismiss()
                    }
                }) {
                    Text("💾 Save Dream")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.purple, Color.indigo]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .cornerRadius(16)
                        .shadow(color: Color.purple.opacity(0.3), radius: 10, x: 0, y: 5)
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding()
        }
        .alert("Dream Saved!", isPresented: $showSaved) {
            Button("OK", role: .cancel) {}
        }
        .navigationTitle("New Dream")
    }
}
