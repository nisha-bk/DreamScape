//
//  InsightView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI

struct InsightView: View {
    @State private var latestDream = "Flying through clouds above a purple city"
    @State private var interpretation = ""
    @State private var isLoading = false

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.3), Color.indigo.opacity(0.2), Color.mint.opacity(0.3)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("🔮 Dream Insights")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.indigo)

                VStack(spacing: 12) {
                    Text("Latest Dream:")
                        .font(.headline)
                        .foregroundColor(.gray)

                    Text(latestDream)
                        .font(.body)
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(12)
                        .shadow(radius: 2)

                    Button(action: generateInterpretation) {
                        Text("✨ Interpret Dream")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.purple, Color.indigo]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(12)
                            .shadow(color: .purple.opacity(0.3), radius: 6)
                    }
                    .disabled(isLoading)
                }

                if isLoading {
                    ProgressView("Analyzing dream...")
                        .padding()
                } else if !interpretation.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Insight:")
                            .font(.headline)
                            .foregroundColor(.gray)

                        Text(interpretation)
                            .font(.body)
                            .padding()
                            .background(.ultraThinMaterial)
                            .cornerRadius(12)
                            .transition(.opacity)
                    }
                }

                Spacer()
            }
            .padding()
        }
    }

    func generateInterpretation() {
        // Placeholder AI logic
        isLoading = true
        interpretation = ""
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            interpretation = "Flying dreams often represent freedom, ambitions, or escape from current limitations. The purple city suggests creativity and emotional insight."
            isLoading = false
        }
    }
}
