//
//  StatsView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI
import Charts
import RealmSwift

struct StatsView: View {
    @ObservedResults(DreamEntry.self) var dreams
    @ObservedResults(MoodEntry.self) var moods

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.mint.opacity(0.2), Color.indigo.opacity(0.15), Color.purple.opacity(0.2)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 28) {
                    Text("📊 Your Dream & Mood Stats")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.indigo)

                    // Dream Frequency Chart
                    GroupBox("🌙 Dreams per Day") {
                        Chart {
                            ForEach(dreamsGroupedByDate(), id: \.key) { day, count in
                                BarMark(
                                    x: .value("Date", day, unit: .day),
                                    y: .value("Dreams", count)
                                )
                                .foregroundStyle(.purple)
                            }
                        }
                        .frame(height: 180)
                    }

                    // Mood Level Trend
                    GroupBox("😊 Mood Over Time") {
                        Chart {
                            ForEach(moods.sorted(by: { $0.date < $1.date })) { mood in
                                LineMark(
                                    x: .value("Date", mood.date),
                                    y: .value("Mood", mood.moodLevel)
                                )
                                .foregroundStyle(.indigo)
                                .interpolationMethod(.catmullRom)
                            }
                        }
                        .frame(height: 180)
                    }

                    Spacer()
                }
                .padding()
            }
        }
    }

    private func dreamsGroupedByDate() -> [(key: Date, value: Int)] {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: dreams) { dream in
            calendar.startOfDay(for: dream.date)
        }
        return grouped.mapValues { $0.count }
            .sorted { $0.key < $1.key }
    }
}
