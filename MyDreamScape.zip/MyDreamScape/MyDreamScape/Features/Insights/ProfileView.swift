import SwiftUI
import RealmSwift

struct ProfileView: View {
    @ObservedResults(DreamEntry.self) var dreams
    @ObservedResults(MoodEntry.self) var moods

    @AppStorage("userName") private var userName: String = "Dreamer"
    @AppStorage("isLoggedIn") private var isLoggedIn: Bool = true

    @State private var editingName = false
    @State private var tempName = ""

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.indigo.opacity(0.2), Color.mint.opacity(0.3), Color.white]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 28) {
                    // Avatar + Name
                    VStack {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.indigo.opacity(0.7))
                            .padding(.bottom, 4)

                        if editingName {
                            TextField("Enter name", text: $tempName, onCommit: {
                                userName = tempName
                                editingName = false
                            })
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 200)
                        } else {
                            HStack(spacing: 8) {
                                Text(userName)
                                    .font(.title2)
                                    .fontWeight(.semibold)

                                Button(action: {
                                    tempName = userName
                                    editingName = true
                                }) {
                                    Image(systemName: "pencil")
                                        .font(.subheadline)
                                }
                            }
                        }
                    }

                    Divider()

                    // Stats Section
                    VStack(spacing: 12) {
                        HStack {
                            Label("Total Dreams", systemImage: "moon.fill")
                            Spacer()
                            Text("\(dreams.count)")
                        }

                        HStack {
                            Label("Mood Entries", systemImage: "face.smiling")
                            Spacer()
                            Text("\(moods.count)")
                        }

                        HStack {
                            Label("First Dream", systemImage: "calendar.badge.clock")
                            Spacer()
                            if let first = dreams.sorted(by: { $0.date < $1.date }).first {
                                Text(first.date.formatted(date: .abbreviated, time: .omitted))
                            } else {
                                Text("—")
                            }
                        }
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)
                    .shadow(radius: 4)

                    Spacer()
                }
                .padding()
            }
        }
        .navigationTitle("Profile")
    }
}
