//
//  SettingsView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//

import SwiftUI
import RealmSwift

struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @Environment(\.colorScheme) var colorScheme

    @ObservedResults(DreamEntry.self) var dreams
    @ObservedResults(MoodEntry.self) var moods

    @State private var showResetConfirmation = false

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Appearance")) {
                    Toggle(isOn: $isDarkMode) {
                        HStack {
                            Image(systemName: isDarkMode ? "moon.fill" : "sun.max.fill")
                                .foregroundColor(isDarkMode ? .yellow : .orange)
                            Text("Dark Mode")
                        }
                    }
                    .toggleStyle(SwitchToggleStyle(tint: .indigo))
                }

                Section(header: Text("Data")) {
                    Button(role: .destructive) {
                        showResetConfirmation = true
                    } label: {
                        Label("Reset All Entries", systemImage: "trash")
                    }
                    .alert("Are you sure?", isPresented: $showResetConfirmation) {
                        Button("Delete All", role: .destructive, action: resetAllData)
                        Button("Cancel", role: .cancel) {}
                    } message: {
                        Text("This will delete all dreams and moods. This action cannot be undone.")
                    }
                }

                Section(header: Text("About")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.gray)
                    }

                    HStack {
                        Text("Test")
                        Spacer()
                        Text("Qwerty")
                            .foregroundColor(.gray)
                    }

                    HStack {
                        Text("Contact")
                        Spacer()
                        Text("support@dreamscape.app")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle("⚙️ Settings")
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }

    private func resetAllData() {
        if let realm = try? Realm() {
            try? realm.write {
                realm.delete(dreams)
                realm.delete(moods)
            }
        }
    }
}
