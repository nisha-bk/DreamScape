//
//  MoodEntry.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI
import RealmSwift

class MoodEntry: Object, ObjectKeyIdentifiable {
    @Persisted(primaryKey: true) var id: ObjectId
    @Persisted var moodLevel: Int
    @Persisted var moodEmoji: String
    @Persisted var date: Date = Date()
}

struct MoodTrackerView: View {
    @ObservedResults(MoodEntry.self, sortDescriptor: SortDescriptor(keyPath: "date", ascending: false)) var moods
    @State private var moodLevel: Double = 3
    @State private var selectedEmoji = "🙂"
    @State private var showSaved = false

    let emojis = ["😡", "😕", "😐", "🙂", "😄"]

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.cyan.opacity(0.3), Color.purple.opacity(0.3), Color.white]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 24) {
                Text("🧘 Mood Tracker")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.indigo)

                VStack(spacing: 16) {
                    Text("How are you feeling?")
                        .font(.headline)

                    Slider(value: $moodLevel, in: 0...4, step: 1)
                        .accentColor(.indigo)

                    Text(emojis[Int(moodLevel)])
                        .font(.system(size: 64))
                        .padding()

                    Button(action: saveMood) {
                        Text("💾 Save Mood")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.purple, Color.indigo]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(14)
                            .shadow(radius: 6)
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                .shadow(radius: 4)

                if showSaved {
                    Text("Mood Saved! ✅")
                        .foregroundColor(.green)
                        .transition(.opacity)
                }

                Divider()

                Text("📅 Mood History")
                    .font(.title3)
                    .fontWeight(.medium)

                List {
                    ForEach(moods) { mood in
                        HStack {
                            Text(mood.moodEmoji)
                                .font(.largeTitle)
                            VStack(alignment: .leading) {
                                Text(mood.date.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text("Mood Level: \(mood.moodLevel)")
                                    .font(.subheadline)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                    .onDelete(perform: deleteMood)
                }
                .listStyle(.plain)

                Spacer()
            }
            .padding()
        }
    }

    func saveMood() {
        let mood = MoodEntry()
        mood.moodLevel = Int(moodLevel)
        mood.moodEmoji = emojis[Int(moodLevel)]

        if let realm = try? Realm() {
            try? realm.write {
                realm.add(mood)
            }
        }

        showSaved = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            showSaved = false
        }
    }

    func deleteMood(at offsets: IndexSet) {
        for index in offsets {
            let mood = moods[index]
            if let realm = mood.realm {
                try? realm.write {
                    realm.delete(mood)
                }
            }
        }
    }
}
