//
//  SearchDreamView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI
import RealmSwift

struct SearchDreamView: View {
    @ObservedResults(DreamEntry.self) var dreams

    @State private var searchText = ""
    @State private var selectedDate: Date? = nil

    var filteredDreams: [DreamEntry] {
        dreams.filter { dream in
            (searchText.isEmpty || dream.text.localizedCaseInsensitiveContains(searchText)) &&
            (selectedDate == nil || Calendar.current.isDate(dream.date, inSameDayAs: selectedDate!))
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.2), Color.indigo.opacity(0.2), Color.white]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("🔍 Search Dreams")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.indigo)

                TextField("Search by keyword...", text: $searchText)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.indigo.opacity(0.2), lineWidth: 1)
                    )

                DatePicker(
                    "Filter by date",
                    selection: Binding<Date>(
                        get: { selectedDate ?? Date() },
                        set: { selectedDate = $0 }
                    ),
                    displayedComponents: .date
                )
                .datePickerStyle(.compact)
                .labelsHidden()


                List {
                    ForEach(filteredDreams) { dream in
                        VStack(alignment: .leading) {
                            Text(dream.text)
                                .font(.body)
                            Text(dream.date.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        .padding(.vertical, 8)
                    }
                }
                .listStyle(.plain)

                Spacer()
            }
            .padding()
        }
    }
}

// Utility Binding to handle optional date
extension Binding where Value == Date? {
    init(_ source: Binding<Date?>, replacingNilWith defaultValue: Date) {
        self.init(
            get: { source.wrappedValue ?? defaultValue },
            set: { source.wrappedValue = $0 }
        )
    }
}
