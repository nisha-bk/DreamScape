//
//  SectionHeader.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI

struct SectionHeader: View {
    let title: String

    var body: some View {
        HStack {
            Text(title)
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(.indigo)
            Spacer()
        }
        .padding(.top)
    }
}

//SectionHeader(title: "📝 Your Dreams")
