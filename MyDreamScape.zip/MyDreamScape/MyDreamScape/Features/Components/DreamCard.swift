//
//  DreamCard.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI

struct DreamCard: View {
    let dream: DreamEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(dream.text)
                .font(.body)
                .foregroundColor(.primary)
                .lineLimit(3)

            Text(dream.date.formatted(date: .abbreviated, time: .shortened))
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
}

//ForEach(dreams) { dream in
//    DreamCard(dream: dream)
//}
