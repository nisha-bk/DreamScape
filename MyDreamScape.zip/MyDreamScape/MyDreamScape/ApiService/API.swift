//
//  API.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/10/25.
//

//import Foundation
//
//let baseURL = "https://dreamscape-api.nishn577.repl.co/api/dreams"
//
//// GET all dreams
//func fetchDreams(completion: @escaping ([DreamEntry]) -> Void) {
//    guard let url = URL(string: baseURL) else { return }
//
//    URLSession.shared.dataTask(with: url) { data, response, error in
//        if let data = data {
//            let dreams = try? JSONDecoder().decode([DreamEntry].self, from: data)
//            DispatchQueue.main.async {
//                completion(dreams ?? [])
//            }
//        }
//    }.resume()
//}
//
//// POST a new dream
//func postDream(text: String, completion: @escaping (DreamEntry?) -> Void) {
//    guard let url = URL(string: baseURL) else { return }
//
//    var request = URLRequest(url: url)
//    request.httpMethod = "POST"
//    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//
//    let body: [String: String] = ["text": text]
//    request.httpBody = try? JSONEncoder().encode(body)
//
//    URLSession.shared.dataTask(with: request) { data, _, _ in
//        if let data = data {
//            let dream = try? JSONDecoder().decode(DreamEntry.self, from: data)
//            DispatchQueue.main.async {
//                completion(dream)
//            }
//        }
//    }.resume()
//}
//
//// DELETE a dream
//func deleteDream(id: Int, completion: @escaping () -> Void) {
//    guard let url = URL(string: "\(baseURL)/\(id)") else { return }
//
//    var request = URLRequest(url: url)
//    request.httpMethod = "DELETE"
//
//    URLSession.shared.dataTask(with: request) { _, _, _ in
//        DispatchQueue.main.async {
//            completion()
//        }
//    }.resume()
//}
