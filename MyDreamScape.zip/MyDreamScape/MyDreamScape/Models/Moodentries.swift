//
//  Moodentries.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import Foundation
import RealmSwift

class MoodEntries: Object, ObjectKeyIdentifiable {
    @Persisted(primaryKey: true) var id: ObjectId
    @Persisted var moodLevel: Int
    @Persisted var moodEmoji: String
    @Persisted var date: Date = Date()
} 
