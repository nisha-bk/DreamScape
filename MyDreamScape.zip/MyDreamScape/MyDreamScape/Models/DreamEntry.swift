//
//  DreamEntry.swift
//  DreamScape
//

import Foundation
import RealmSwift

class DreamEntry: Object, Identifiable {
    @objc dynamic var id = UUID().uuidString
    @objc dynamic var text = ""
    @objc dynamic var date = Date()

    override static func primaryKey() -> String? {
        return "id"
    }
}

