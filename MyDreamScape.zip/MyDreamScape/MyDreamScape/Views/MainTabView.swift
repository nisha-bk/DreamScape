import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            DreamListView()
                .tabItem {
                    Label("Journal", systemImage: "book.fill")
                }

            InsightView()
                .tabItem {
                    Label("Insights", systemImage: "lightbulb")
                }

            MoodTrackerView()
                .tabItem {
                    Label("Mood", systemImage: "face.smiling")
                }
            SearchDreamView()
                    
                .tabItem {
                        Label("Search", systemImage: "magnifyingglass")
                }

            StatsView()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar")
                }

            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape")
                }
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.circle")
                }
        }
        .accentColor(.indigo)
    }
    
}
