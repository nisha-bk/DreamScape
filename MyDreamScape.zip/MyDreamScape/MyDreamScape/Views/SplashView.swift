//
//  SplashView.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import SwiftUI

struct SplashView: View {
    @State private var isActive = false

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.indigo.opacity(0.9), Color.purple.opacity(0.9), Color.cyan.opacity(0.9)]),
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Image(systemName: "moon.stars.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
                
                Text("DreamScape")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                isActive = true
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            MainTabView()
        }
    }
}
