//
//  RealmManager.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//


import Foundation
import RealmSwift

class RealmManager {
    private var realm: Realm

    init() {
        do {
            realm = try Realm()
        } catch let error {
            fatalError("Failed to initialize Realm: \(error.localizedDescription)")
        }
    }

    // MARK: - CRUD Operations

    func addDream(_ dream: DreamEntry) {
        do {
            try realm.write {
                realm.add(dream)
            }
        } catch {
            print("Error adding dream: \(error.localizedDescription)")
        }
    }

    func fetchDreams() -> Results<DreamEntry> {
        return realm.objects(DreamEntry.self).sorted(byKeyPath: "date", ascending: false)
    }

    func deleteDream(_ dream: DreamEntry) {
        do {
            try realm.write {
                realm.delete(dream)
            }
        } catch {
            print("Error deleting dream: \(error.localizedDescription)")
        }
    }

    func updateDream(_ dream: DreamEntry, newText: String) {
        do {
            try realm.write {
                dream.text = newText
                dream.date = Date()
            }
        } catch {
            print("Error updating dream: \(error.localizedDescription)")
        }
    }
}
