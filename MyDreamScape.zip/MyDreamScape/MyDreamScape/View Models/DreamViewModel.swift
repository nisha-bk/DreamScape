//
//  DreamViewModel.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 7/9/25.
//

import Foundation
import RealmSwift

class DreamViewModel: ObservableObject {
    private let realmManager = RealmManager()
    
    @Published var dreams: [DreamEntry] = []

    init() {
        loadDreams()
    }

    func loadDreams() {
        let results = realmManager.fetchDreams()
        dreams = Array(results)
    }

    func addDream(text: String) {
        let newDream = DreamEntry()
        newDream.text = text
        realmManager.addDream(newDream)
        loadDreams()
    }

    func deleteDream(at offsets: IndexSet) {
        offsets.forEach { index in
            let dream = dreams[index]
            realmManager.deleteDream(dream)
        }
        loadDreams()
    }

    func updateDream(_ dream: DreamEntry, newText: String) {
        realmManager.updateDream(dream, newText: newText)
        loadDreams()
    }
}
