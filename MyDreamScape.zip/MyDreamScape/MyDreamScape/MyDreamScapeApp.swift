//
//  MyDreamScapeApp.swift
//  MyDreamScape
//
//  Created by Allnet Systems on 5/14/25.
//

import SwiftUI
import RealmSwift

@main
struct MyDreamScapeApp: SwiftUI.App {
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = true

    var body: some Scene {
        WindowGroup {
            if isLoggedIn {
                SplashView()
                    .environment(\.realmConfiguration, Realm.Configuration.defaultConfiguration)
            } 
        }
    }
}


